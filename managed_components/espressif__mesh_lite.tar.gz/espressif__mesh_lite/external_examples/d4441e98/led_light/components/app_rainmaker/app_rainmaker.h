/*
 * SPDX-FileCopyrightText: 2022-2023 Espressif Systems (Shanghai) CO LTD
 *
 * SPDX-License-Identifier: Apache-2.0
 */

#pragma once

void app_rainmaker_start(void);

void esp_rmaker_control_light_by_user(char* data);
