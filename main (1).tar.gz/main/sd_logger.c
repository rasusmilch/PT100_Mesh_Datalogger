#include "sd_logger.h"

#include <errno.h>
#include <inttypes.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>

#include "esp_log.h"
#include "esp_vfs_fat.h"

static const char* kTag = "sd_logger";

static size_t
DefaultOr(const size_t value, const size_t fallback)
{
  return (value == 0) ? fallback : value;
}

void
SdLoggerInit(sd_logger_t* logger, const sd_logger_config_t* config)
{
  if (logger == NULL) {
    return;
  }
  memset(logger, 0, sizeof(*logger));
  strncpy(logger->mount_point, "/sdcard", sizeof(logger->mount_point) - 1);

  const size_t default_batch = 128 * 1024;
  const size_t default_tail_scan = 256 * 1024;
  const size_t default_buffer = 64 * 1024;

  logger->config.batch_target_bytes =
    DefaultOr(config ? config->batch_target_bytes : 0, default_batch);
  logger->config.tail_scan_bytes =
    DefaultOr(config ? config->tail_scan_bytes : 0, default_tail_scan);
  logger->config.file_buffer_bytes =
    DefaultOr(config ? config->file_buffer_bytes : 0, default_buffer);
}

static void
BuildDailyCsvPath(const sd_logger_t* logger,
                  int64_t epoch_seconds,
                  char* date_out,
                  size_t date_out_size,
                  char* path_out,
                  size_t path_out_size)
{
  time_t time_seconds = (time_t)epoch_seconds;
  struct tm time_info;
  gmtime_r(&time_seconds, &time_info);

  strftime(date_out, date_out_size, "%Y-%m-%d", &time_info);

  snprintf(path_out,
           path_out_size,
           "%s/%s.csv",
           logger->mount_point,
           date_out);
}

static esp_err_t
WriteHeaderIfEmpty(sd_logger_t* logger)
{
  struct stat stat_buffer;
  if (fstat(fileno(logger->file), &stat_buffer) != 0) {
    return ESP_FAIL;
  }
  if (stat_buffer.st_size > 0) {
    return ESP_OK;
  }

  static const char* const kHeader =
    "seq,epoch_utc,iso8601_utc,raw_rtd_ohms,raw_temp_c,cal_temp_c,flags,node_id\n";
  const size_t header_len = strlen(kHeader);
  return SdCsvAppendBatchWithReadbackVerify(
    logger->file, (const uint8_t*)kHeader, header_len);
}

esp_err_t
SdLoggerMount(sd_logger_t* logger, spi_host_device_t host, int cs_gpio)
{
  if (logger == NULL) {
    return ESP_ERR_INVALID_ARG;
  }

  sdmmc_host_t sd_host = SDSPI_HOST_DEFAULT();
  sd_host.slot = host;

  sdspi_device_config_t slot_config = SDSPI_DEVICE_CONFIG_DEFAULT();
  slot_config.gpio_cs = cs_gpio;
  slot_config.host_id = host;

  esp_vfs_fat_sdmmc_mount_config_t mount_config = {
    .format_if_mount_failed = false,
    .max_files = 5,
    .allocation_unit_size = 16 * 1024,
  };

  sdmmc_card_t* card = NULL;
  esp_err_t result = esp_vfs_fat_sdspi_mount(
    logger->mount_point, &sd_host, &slot_config, &mount_config, &card);

  if (result != ESP_OK) {
    ESP_LOGW(kTag, "SD mount failed: %s", esp_err_to_name(result));
    return result;
  }

  logger->is_mounted = true;
  logger->card = card;
  ESP_LOGI(kTag, "SD mounted at %s", logger->mount_point);
  return ESP_OK;
}

static esp_err_t
ApplyResumeInfo(sd_logger_t* logger, FILE* file, const char* path)
{
  SdCsvResumeInfo resume_info = { 0 };
  esp_err_t resume_result = SdCsvFindLastSequenceAndRepairTail(
    file, logger->config.tail_scan_bytes, &resume_info);
  if (resume_result != ESP_OK) {
    ESP_LOGE(kTag, "Failed to scan/repair %s: %s", path, esp_err_to_name(resume_result));
    return resume_result;
  }
  if (resume_info.file_was_truncated) {
    ESP_LOGW(kTag, "%s tail repaired after power loss", path);
  }
  if (resume_info.found_last_sequence) {
    if (resume_info.last_sequence > logger->last_sequence_on_sd) {
      logger->last_sequence_on_sd = resume_info.last_sequence;
    }
    ESP_LOGI(kTag, "Resume: last seq on %s = %u", path, resume_info.last_sequence);
  }
  return ESP_OK;
}

esp_err_t
SdLoggerEnsureDailyFile(sd_logger_t* logger, int64_t epoch_utc)
{
  if (logger == NULL) {
    return ESP_ERR_INVALID_ARG;
  }
  if (!logger->is_mounted) {
    return ESP_ERR_INVALID_STATE;
  }

  char date_string[16];
  char path[128];
  BuildDailyCsvPath(logger, epoch_utc, date_string, sizeof(date_string), path, sizeof(path));

  if (logger->file != NULL && strcmp(logger->current_date, date_string) == 0) {
    return ESP_OK; // already open for today
  }

  SdLoggerClose(logger);

  logger->file = fopen(path, "a+b");
  if (logger->file == NULL) {
    ESP_LOGE(kTag, "fopen failed for %s: %s (%d)", path, strerror(errno), errno);
    return ESP_FAIL;
  }

  if (logger->file_buffer != NULL) {
    free(logger->file_buffer);
    logger->file_buffer = NULL;
  }
  logger->file_buffer = (uint8_t*)malloc(logger->config.file_buffer_bytes);
  if (logger->file_buffer != NULL) {
    setvbuf((FILE*)logger->file,
            (char*)logger->file_buffer,
            _IOFBF,
            logger->config.file_buffer_bytes);
  }

  esp_err_t resume_result = ApplyResumeInfo(logger, logger->file, path);
  if (resume_result != ESP_OK) {
    return resume_result;
  }

  esp_err_t header_result = WriteHeaderIfEmpty(logger);
  if (header_result != ESP_OK) {
    ESP_LOGE(kTag, "Failed to write header to %s", path);
    return header_result;
  }

  strncpy(logger->current_date, date_string, sizeof(logger->current_date) - 1);
  logger->current_date[sizeof(logger->current_date) - 1] = '\0';
  return ESP_OK;
}

esp_err_t
SdLoggerAppendVerifiedBatch(sd_logger_t* logger,
                            const uint8_t* batch_bytes,
                            size_t batch_length_bytes,
                            uint32_t last_sequence_in_batch)
{
  if (logger == NULL || logger->file == NULL) {
    return ESP_ERR_INVALID_STATE;
  }
  if (batch_bytes == NULL || batch_length_bytes == 0) {
    return ESP_ERR_INVALID_ARG;
  }

  fseek(logger->file, 0, SEEK_END);
  esp_err_t result =
    SdCsvAppendBatchWithReadbackVerify(logger->file, batch_bytes, batch_length_bytes);
  if (result == ESP_OK) {
    logger->last_sequence_on_sd = last_sequence_in_batch;
  }
  return result;
}

void
SdLoggerClose(sd_logger_t* logger)
{
  if (logger == NULL) {
    return;
  }
  if (logger->file != NULL) {
    fclose(logger->file);
    logger->file = NULL;
  }
  if (logger->file_buffer != NULL) {
    free(logger->file_buffer);
    logger->file_buffer = NULL;
  }
  logger->current_date[0] = '\0';
}
